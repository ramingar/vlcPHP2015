<?php
return array (
    'filename'=> '../data/usuarios.txt',
    'config1'=>'data1',
    'config2'=>'data2',
    'view_path'=>$_SERVER['DOCUMENT_ROOT'].'/../modules/application/src/application/views',
    'db'=>array('host'=>'localhost', 
                'user'=>'root',
                'password'=>'1234',
                'database'=>'crud'),
    //'adapter'=>'Txt',
    'adapter'=>'Mysql',
    
);