<?php
return array(
    'modules'=>array(
        'core',
        //'Zend-developers-tools',
        'application',
    ),
);