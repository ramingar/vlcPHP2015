<?php
return array(
    'modules'=>array(
                'core',
                'application',   
            ),
);