<?php
return array (
    'core1'=>'data1',
);