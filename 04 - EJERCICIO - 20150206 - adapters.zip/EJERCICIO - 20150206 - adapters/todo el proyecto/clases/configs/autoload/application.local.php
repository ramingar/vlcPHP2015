<?php

return array (    
    'db'=>array('host'=>'localhost', 
                'user'=>'php',
                'password'=>'1234',
                'database'=>'crud'),
    
);