phpzero
=======

Formación en PHP a través de buenas prácticas y conceptos sólidos: desde qué es, hasta los frameworks mas usados del mercado.

<a href="http://agustincl.github.io/phpzero/">PHPZero</a>
