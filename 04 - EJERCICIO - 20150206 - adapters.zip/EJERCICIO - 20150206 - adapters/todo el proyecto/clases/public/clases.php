<?php

/**
 * Objeto para plazmar graficos en un papel
 */
boli {
    color
    marca
    material
    precio
    cantidad_tinta
    peso
    sabor
        
    escribir
    dibujar
    -jugar
    abrir
    cerrar
    -lanzar
    -chupar
    -urgar
    vaciar
    llenar
    -taladrar
    -rebobinar
    
}

papel
{
    dimension
    material
    color
    grosor
    forma
    textura
    precio
    
    romper
    doblar
    cortar
    arrugar
    destruir
    guardar
    dibujar
    escribir
    
}

grafico
{
    tipo
    color
    lista_puntos
    dimensiones
    
    ampliar
    reducir
    rotar
    pintar
    colorear
    -regalar    
}

