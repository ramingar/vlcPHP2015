<?php

return array (
    'filename'=> '../data/usuarios.txt',
    'config1'=>'data1',
    'config2'=>'data2'
    
);